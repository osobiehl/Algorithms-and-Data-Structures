type 'make' in this directory to compile both bonus assignments
